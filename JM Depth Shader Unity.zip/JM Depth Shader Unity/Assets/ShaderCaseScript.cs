﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[ExecuteInEditMode] // Allows the program to run in edit mode
public class ShaderCaseScript : MonoBehaviour { // declares that this class inherets from MonoBehaviour
    public Shader ReplacementShader; // Creates a placeholder for the Cg shader script as well as a variable name for use
    void OnEnable() // When the script is activated, use the replacement shader instead of Unity's default shaders
    {
        if (ReplacementShader != null) GetComponent<Camera>().SetReplacementShader(ReplacementShader, "RenderType");
    }
    void OnDisable() // When the script is disabled, reset the shaders
    {
        GetComponent<Camera>().ResetReplacementShader();
    }
}
